class StringBuffer2{
  //mutable strings always use Stringbuffer
  public static void main(String argsp[]){
    StringBuffer sb=new StringBuffer("Hello Amazonians");

    sb.insert(5," Lets use the Amazon Echo");
    System.out.println(sb);
    
  }
}

//lseek in file handling , right ?
