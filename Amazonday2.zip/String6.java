class String6{

  public static void main(String args[]){
    String s1="Amazon EC2";//string 

    String s2="AWS";
    System.out.println(s1.substring(0,3));
    //System.out.println(s2);
    //System.out.println(s3);
    
  }
}