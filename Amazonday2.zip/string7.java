class String7{

  public static void main(String args[]){
    String s1="   Amazon EC2    ";//string 

    String s2="LinkedIn is an American business and employment-oriented online service that operates via websites and mobile apps. Launched on May 5, 2003, the platform is primarily used for professional networking and career development, and allows LinkedIn job seekers to post their CVs and employers to post jobs.";
    System.out.println(s2.replace("and","&"));
    //System.out.println(s2);
    //System.out.println(s3);
    
  }
}