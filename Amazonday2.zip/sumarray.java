import java.util.*;
 
class sum
{
  public static void main(String args[]) 
    {
      int acc=0;
      Scanner sc=new Scanner(System.in);
      System.out.println("Please ENTER Number of Items:");
      int n=sc.nextInt();
      int[] array = new int[n];
      System.out.println("Please ENTER Items:");
      for(int i=0;i<n;i++)
        array[i]=sc.nextInt();
 
      for(int i=0;i<n;i++)
        acc=acc+array[i];
 
     System.out.println("The Total is "+acc);
    }
}