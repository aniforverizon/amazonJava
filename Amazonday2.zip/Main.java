class Multiplexer{

  //name of the function is same , but signature is different


  //Signature => return type, number of parameters, type of parameters, and order of parameters
  //method overloading
  //int a and int b are known formal parameters and arguments
  static int multiply(int a,int b){
    System.out.println("Function1 gets called");
    return a*b;
  }

   static float multiply(float a,float b,float c){
        System.out.println("Function2 gets called");
    // int d=int(b);
    return a*b*c;
  }
}

class Main {
  
  public static void main(String[] args) {
    System.out.println("Hello world!");
    
    System.out.println(Multiplexer.multiply(5,6));
    //f means float, if f is not specified it is double 
    System.out.println(Multiplexer.multiply(5.0f,6.0f,7.0f));
    
  }
}