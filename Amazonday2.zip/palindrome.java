import java.util.*;

class StringQuestion4 {
    public static void main(String[] args){
        StringBuffer str=new StringBuffer();
        StringBuffer temp=new StringBuffer();
        System.out.println("Enter a String:");
        Scanner sc=new Scanner(System.in);
        str.append(sc.nextLine());
        temp.append(str);
        temp.reverse();
      System.out.println("temp is"+temp);
      System.out.println("str is"+str);
      System.out.println(str.toString().equals(temp.toString()));
        if (str.toString().equals(temp.toString())) {
            System.out.println("String is a Palindrome");
        } else {
            System.out.println("String is not a Palindrome");
        }
    }
}