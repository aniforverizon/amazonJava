import java.util.*;



class Generate{

	public static void main(String args[]){

		String[] names=new String[];
      String tmp;
		for (int i=0;i<10;i++){
      tmp=scan.N
			names[i]
			System.out.println(names);

		}

	}

}