class String5{

  public static void main(String args[]){
    String s1="AWS";//string 

    String s2="AWS";
    String s3="Aindle";
    //from the point of mismatch , it will return the difference
   // A-A, W-W, S-S
    //A-K => 
    
//ASCII Codes 
    System.out.println(s1.compareTo(s2));
    System.out.println(s1.compareTo(s3));
        System.out.println(s3.compareTo(s1));
    
    System.out.println(s1);
    System.out.println(s2);
    //System.out.println(s3);
    
  }
}