class String2{

public static void main(String args[]){

  String s2="Amazon"; //immutable 
  String s3="ok";
    System.out.println(s2==s3);
  String s4=new String("Amazon");
  int x=500;
  int y=500;
  Integer a=520;
  Integer b=520;
  System.out.println(s2==s4);
  System.out.println(Integer.toHexString (s2.hashCode()));
  System.out.println(Integer.toHexString (s3.hashCode()));
  System.out.println(Integer.toHexString (s4.hashCode()));
  //printing addresses
  System.out.println(System.identityHashCode (s4));
  System.out.println(System.identityHashCode (s2));
  System.out.println(System.identityHashCode (s3));
  System.out.println("x identity"+System.identityHashCode (x));
    System.out.println("y identity"+System.identityHashCode (y));

  System.out.println("a identity"+System.identityHashCode (a));
    System.out.println("b identity"+System.identityHashCode (b));
  
  System.out.println(s2.equals(s4));
// int v/s Integer
}
  
}