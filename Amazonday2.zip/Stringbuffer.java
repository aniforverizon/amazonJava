class StringBuffer1{
  //mutable strings always use Stringbuffer
  public static void main(String argsp[]){
    StringBuffer sb=new StringBuffer("Hello Amazonians");

    sb.append(" Lets use the Amazon Echo");
    System.out.println(sb);
    
  }
}