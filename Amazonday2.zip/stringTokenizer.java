 import java.util.StringTokenizer;

class StrToken {
    public static void main(String[] args) {
        StringTokenizer st=new StringTokenizer("AMAZON cloud establishes next level of trust");
     // StringTokenizer st1=new StringTokenizer("192.168.0.1",".");
      StringTokenizer st1=new StringTokenizer("192_168_0_1_5_6_7-8","_-"); //delimiter
      System.out.println(st1.countTokens());
      int i=0;  
      while(st1.hasMoreTokens()){
          if (i==3){
            break;
          }  
            System.out.println(st1.nextToken());
      i++;  
      }
    }
}
