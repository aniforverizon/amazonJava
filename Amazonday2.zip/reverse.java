import java.util.*;

class Reverse{
  //mutable strings always use Stringbuffer
  public static void main(String argsp[]){
    Scanner input=new Scanner(System.in);
    
    StringBuffer sb=new StringBuffer("");
    sb.append(input.nextLine());

    sb.reverse();
    System.out.println(sb);
    
  }
}

//lseek in file handling , right ?
