class String1{

public static void main(String args[]){

  String s="Amazon"; //immutable 
  System.out.println(s.concat("is a great company to work with"));
  s="Alok";
  System.out.println(s);
  s=s.concat(" is a great company to work with");
  System.out.println(s);
}
  
}