class String3{

  public static void main(String args[]){
    String s1="AWS";//string 

    char cha1[]={'A','m','a','z','o','n'};//character array
    String s2=new String(cha1);//converting character array to string
    //no null character at end of string as C
    String s3=new String("Kindle");//new
    System.out.println(s1);
    System.out.println(s2);
    System.out.println(s3);
    
  }
}