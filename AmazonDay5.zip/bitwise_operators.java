class BitwiseOperators{

public static void main(String args[]){

  int a=5;

  int b=7;
// 0111 => 7 , 0101 => 5

  //0 & 0 =>0
  //0&1 =>0
  //1&1=>1
  //1&0 =>0
    // 0101
  //&//0111
  //   0101
  //
  System.out.println("a&b value is "+(a&b));
  
  System.out.println("a&b value is "+(a+b));
}
  
  
}