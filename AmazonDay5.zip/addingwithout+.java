
class AddingWithout{
 //addition without a + sign
  //withou
  public static int addIterative(int a ,int b){

    while (b!=0){
      int carry=(a&b); //from your equation

      //110 => 6
      //1000 => adding zeroes and remove from left
      //0000
      // actual addition in computers take place like this
      System.out.println("value of b before shift "+ b );
      a=a^b; //sum of 2 using XOR
      b=carry<<1; //left shift
      System.out.println("value of b is "+ b );
      //  
      
    }

    return a;
  }
  public static void main (String args[]){

   //a =5

    //6 
     //add things into a step by step=> and reduce b

    // 5+1 =>6 , 6-1=5
    // 6+1 => 7 , 5-1=4
    //7+1=> 8. 4-1 =3


    //11
    
    System.out.println("a + b "+ addIterative(5,6) );
    
  }
}