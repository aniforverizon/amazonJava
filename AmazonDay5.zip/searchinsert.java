/**

Sorted array :

=> retrn index if target found
=> return the relevant index if it were inserted in order


[1,3,5,6], 5 =>2
[1,3,5,6] ,2 => 1
[1,3,5,6] , 7 => 4
[1,3,5,6] , 0 =>0


**/
 class SearchInsert {
    public static int serach(int[] arr, int x, int low, int high){
        int mid=0;
        while (low!=high){
            mid=(low+high)/2;
            if (x==arr[mid]){
                return mid;
            } else if (x>arr[mid]) {
                low=mid+1;
            } else {
                high=mid-1;
            }
        }
        return mid+1;
    }
    public static void main(String[] args){
        int[] arr={1,3,5,6};
        System.out.println("Relavent index for 5:"+serach(arr,5, 0, arr.length));
        System.out.println("Relavent index for 2:"+serach(arr,2, 0, arr.length));
        System.out.println("Relavent index for 7:"+serach(arr,7, 0, arr.length));
        System.out.println("Relavent index for 0:"+serach(arr,0, 0, arr.length));
    }
}