import java.util.*;
 
class Tonmoy {
  public static void main(String[] args) {    
    int[] arr = new int[] {-2,-1,-3,4,-1,2,1,-5,4};
    //for(int i = 1; i<arr.length; i++) {
    //  System.out.println("current element of array is : " +arr[i]);
    System.out.println("max sum of subbarray is : " +sum(arr));
  }
  public static int sum(int[] arr) {
    int sum = arr[0];
    int current = arr[0];
    for(int i = 1; i<arr.length; i++) {
        System.out.println("Currently checking the element : " +arr[i]);
        if(current>0)
              current += arr[i];
        else
            current = arr[i];
        sum = Math.max(current,sum);
        System.out.println("highest sum of subaaray is : "+sum);
      }        
    return sum;    
  }
}