import java.util.Arrays;

class Bubble{

static void bubbleSort(int arr[]){
int size=arr.length;

  for (int i=0;i<size-1;i++){

    for (int j=0;j<size-i-1;j++){
      if (arr[j]>arr[j+1]){

        arr[j] = arr[j]+arr[j+1] ;
          arr[j+1]=arr[j]-arr[j+1]  ;
        arr[j]=arr[j]-arr[j+1] ;
        
      }
    }
  }
  
}
  public static void main(String args[]){
    int [] data={12,15,16,1,2,5,0,9,11};
    //static functions means no instantiation, they can be called via class name
    
    System.out.println("Original array");
    System.out.println(Arrays.toString(data));
    Bubble.bubbleSort(data);

    System.out.println("Sorted array in ascending order");
    System.out.println(Arrays.toString(data));
  }
  
}