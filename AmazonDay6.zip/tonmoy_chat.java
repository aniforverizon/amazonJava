import java.util.*;
 
	class Message{
		String name;
		List<Chat> ch = new ArrayList<>();
 
		void addChat(Chat c) {
			this.ch.add(c);
		}
		void showMessage() {
			for(int i=0;i < this.ch.size();i++) {
				ch.get(i).showDetail();
				System.out.println();
			}
		}
	}
 
	class Chat{
		String name;
    String msg;
		Map<String, String> messageHistory = new HashMap<>();
 
		Chat(String name, String msg){
			this.name = name;
      this.msg = msg;
			messageHistory.put(name, msg); 
		}
 
		void showDetail() {
			for (Map.Entry<String,String> entry : this.messageHistory.entrySet()) {
				System.out.println(">>" + entry.getKey()+" : "+entry.getValue());
			 }
		}
	}
 
class Tonmoy {
  public static void main(String[] args) {
    Message m1 = new Message();
    Chat c1 = new Chat("Tanay", "Hello");
    Chat c2 = new Chat("Tonmoy", "gm");
    Chat c3 = new Chat("Ram", "good");
    Chat c4 = new Chat("Sharan", "hi");
    Chat c5 = new Chat("Gourab", "got it");
    m1.addChat(c1);
		m1.addChat(c2);
		m1.addChat(c3);
    m1.addChat(c3);
		m1.addChat(c3);
		m1.showMessage();
  }
}