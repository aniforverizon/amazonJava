import java.util.*;
 
class calc{
 
  public static void add(int x,int y){
    int add=x+y;
    System.out.println("addition of " +x+ " and " +y+ "    :"+add);
 
  }
   public static void sub(int x,int y){
    int sub=x-y;
    System.out.println("Subtraction of " +x+ " and " +y+ "  :" +sub);
 
  }
  public static void mul(int x,int y){
    int mul=x*y;
    System.out.println("Multiplication of " +x+ " and " +y+ "  :" +mul);
 
  }
  public static void div(int x,int y){
    int div=x/y;
    System.out.println("Division of " +x+ " and " +y+ "  :" +div);
 
  }
 
public static void main(String args[]){
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter x value");
  int x=sc.nextInt();
  System.out.println("Enter y value");
  int y=sc.nextInt();
  add(x,y);
  sub(x,y);
  mul(x,y);
  div(x,y);
}
}