import java.util.Scanner;
 
class Vote{
 
  public static void main(String[] args){
 
    Scanner sc = new Scanner(System.in);
    String cpn;
    System.out.println("Please enter no. of item");
    int n = sc.nextInt();
    int sum = 0;
    for(int i=0;i < n;i++){
      System.out.println("Item COST:");
      int price = sc.nextInt();
      sum+=price;
    }
    int finalCost = 0;
    System.out.println("Enter valid cpn code:");
    cpn = sc.nextLine();
 
    if(cpn.equals("RAKHI200")){
      if(sum >= 500){
      finalCost = (sum/2);
      System.out.println("After 50% discount, Total:"+finalCost);
    }else if(sum >= 200){
        finalCost = (sum*70)/100;
      System.out.println("After 70% discount, Total:"+finalCost);
 
    }else if(sum >= 100){
      finalCost = (sum*80)/100;
      System.out.println("After 80% discount, Total:"+finalCost);
 
    }else{
      System.out.println("No discount!!");
    }
 
    }else{
      System.out.println("Invalid cpn code:");
    }
    System.out.println("Total: "+finalCost);
 
  }
}
