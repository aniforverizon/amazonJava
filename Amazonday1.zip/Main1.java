class Amazon {
  public static void main(String[] args) {
  //variable declaration => data type
    int var=7;
    //String is a class
    String firstName="Anubhav";
    String lastName="Chaturvedi";
    System.out.println("Amazon is a great company to work with");
    System.out.println("number of arguments is "+args.length);
  //concatanation
    System.out.println("I am a professional with "+var+" years of experience");
    System.out.println("My name is "+firstName+" "+lastName);
    String fullName;
    fullName=firstName+lastName;
    System.out.println("String length is "+ fullName.length());
    for (int i=0;i<args.length;i++){
    
    System.out.println(args[i]);  
      //System is a class , out is a object, println is function
    
    
  }
}
}

//class => functions 
//these are comments
//Object oriented programming => classes 

// execution of Java Program => starts with the main function

//public => which means it is an access specifier
//public means access from anywhrer
//access specifiers =>public,private,protected

//class and objects
//static members to be called you do not need objects to invoke them
//object is represenation of a class => and we can call 
//member functions by using the objects
//Ama= new Amazon
//Ama.main()
//command line argguments => 