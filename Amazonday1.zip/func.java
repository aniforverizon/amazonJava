import java.util.*;
class code {              // 2    3 formal parameters
  public static void add(int x,int y){ 
    int sum=x+y;
    System.out.println("addition is "+ sum);

  }
  public static void main(String[] args) {
  //variable declaration => data type
    Scanner sc = new Scanner(System.in);
    System.out.println("Please enter no. 1");
    int a = sc.nextInt();
     System.out.println("Please enter no. 2");
    int b = sc.nextInt();

    add(a,b); //actual parameters
    //System.out.println(l1.equals(l2));
  //  System.out.println("type is"+l1.getClass().getName());
    
  }

}