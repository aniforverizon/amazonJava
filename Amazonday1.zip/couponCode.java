import java.util.*; //this provides Scanner
//java.util is a package providing functions
//like scanf in C , stdio.h ?

class code {

  public static void main(String[] args) {
  //variable declaration => data type
  String l1="Anubhav";


    String l2="Anubhav1";
  //equals helps you out in comparing two strings
    System.out.println(l1.equals(l2));
    System.out.println("type is"+l1.getClass().getName());
    
  }

}