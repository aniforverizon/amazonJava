import java.util.*; //this provides Scanner
//java.util is a package providing functions
//like scanf in C , stdio.h ?

class vote {

public static void main (String args[]){

  //int age=18;
//this is a class which provides input output functions
  Scanner sc=new Scanner(System.in); //to crete object
  System.out.println("Please enter your age");
  int age=sc.nextInt();
  if(age>=18){
    System.out.println("You can vote");
    
  }
  else if (age==17){
    System.out.println("after one year");
  }

  else{
    System.out.println("You cannot vote");
  }
}

  
}