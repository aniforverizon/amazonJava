class loop {

  public static void main(String[] args) {
  
    int acc=0;
    for (int i=0;i<10;i++){
      System.out.println("number counter is "+i);

      acc=acc+i;
      System.out.println("the accoumulated value is "+acc);
    }
    System.out.println("the accoumulated value is "+acc);
  }

}