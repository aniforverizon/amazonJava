import java.util.*;
 
class Cart {
    public static void main(String[] arg) {
        Scanner user_input = new Scanner(System.in);
        System.out.print("Number of items: ");
        int no_of_items = user_input.nextInt();
        int total = 0;
        String CouponCode;
 
        for (int x = 0; x < no_of_items; x++) {
            System.out.print("print price of item "+(x+1)+": ");
            total = total + user_input.nextInt();
        }
 
        user_input.nextLine();
        System.out.print("Coupon code: ");
 
        CouponCode = user_input.nextLine();
 
        if(CouponCode.equals("RAKHI2022")) {
            if(total > 500) {
                total = total - total/2;
            } else if(total > 200) {
                total = total - ((total * 30)/100);
            } else if (total > 100) {
                total = total - ((total * 20)/100);
            }
        }
 
        System.out.println("Amount to be paid: "+total);
    }
}