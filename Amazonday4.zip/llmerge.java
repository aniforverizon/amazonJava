import java.util.*;
 
class Node {
      int val;
      Node next;
}
class mergeList {
    public static Node mergeLists(Node list1, Node list2) {
        if (list1.val > list2.val) {
            Node temp = list1;
            list1 = list2;
            list2 = temp;
        }        
        Node ans = list1;        
        while (list1 != null && list2 != null) {
            Node temp = null;
            while (list1 != null && list1.val <= list2.val) {
                temp = list1;
                list1 = list1.next;
            }
            temp.next = list2;
            Node var = list1;
            list1 = list2;
            list2 = var;
        }
      return ans;
    }
  public static void main(String args[]){
 
    Node newnode1=new Node();
    Node newnode2=new Node();
    Node newnode3=new Node();
    Node newnode4=new Node();
    newnode1.val=1;
    newnode2.val=2;
    newnode3.val=3;
    newnode4.val=4;
    newnode1.next=newnode2;
    newnode2.next=newnode3;
    newnode3.next=newnode4;
    newnode4.next=null;
    //1,2,3,4  => l1
    //      *
    //2,3,4,5 => l2
    //      *
    //1<2 => 1,
 
    Node newnode11=new Node();
    Node newnode12=new Node();
    Node newnode13=new Node();
    Node newnode14=new Node();
    newnode11.val=2;
    newnode12.val=3;
    newnode13.val=4;
    newnode14.val=5;
    newnode11.next=newnode12;
    newnode12.next=newnode13;
    newnode13.next=newnode14;
    newnode14.next=null;
    Node snode = new Node();
    snode = mergeLists(newnode1,newnode11);
    while(snode!=null) {
          System.out.println("values : "+snode.val);
          snode = snode.next;
        }
    }    
}