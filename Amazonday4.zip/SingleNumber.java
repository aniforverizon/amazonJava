//1,1,2,2,3,3,4,5,5,6,6,7,7,8,8
//you have to find that single number, which is present only once

class SingleNumber{

  public static int singleNumber(int [] nums){
    int result=0;
    for (int i=0;i<nums.length;i++){
      result=result ^ nums[i];
    }
    return result;
  }
  public static void main(String args[]){

    int arr[]={1,1,2,2,3,3,4,4,5,5,6,6,717,8,8};

    System.out.println("single number in the array is "+singleNumber(arr));
  }
}

//xor gates 