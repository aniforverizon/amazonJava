import java.util.ArrayList;

class ArrayList1{

  public static void main(String args[]){
    //arraylist is a resizable array
    ArrayList<String> list=new ArrayList<>();

    list.add("Amazon Echo");

    list.add("Amazon Kindly");

    list.add("Amazon cart");
    list.set(1,"Amazon EC2"); //change on index 1

    System.out.println("list is "+list);
  }
  
}