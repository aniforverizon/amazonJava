import java.util.*;
 
class RemDups {
  public static void main(String[] args) {
    int[] arr = {1,1,2,2,3,4,4,5,5,5};
    int i = 0;
    int j = 0;
    while(i < arr.length) {
	      if(arr[i] > arr[j]) {
		      j++;
		      arr[j] = arr[i];
	        }
	      i++;
    }
    System.out.println("no of unique elemetns are : "+(j+1));
	for(i = 0; i<=j; i++)
      System.out.println("elemetns are : "+arr[i]);
  }
}