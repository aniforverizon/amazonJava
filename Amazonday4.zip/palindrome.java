//aba palindrome=>
//motom
//madam
//=> codes which are detecting palindrome, but withut converting them into strings. 
//121, 222, 323, 212 => palindromes
//whether you read it from left or from right, it is the same
//for every upcoming number, you have to check whether palindrome or not without using strings
//can someone tell me logic to solve this?
//charAt will apply for strings or characters 
//modulo and divide =>  4:05 pm .

import java.util.Scanner;
class PalindromeStr {
    static boolean isPalindrome(int n){
        int temp=0,x=n;
        while(n>0){
            temp=((10*temp)+(n%10));
            n/=10;
        }
        if(temp==x)
            return true;
        return false;
    }

  static int numberOfdigits(int n) {
		if(n == 0) {
 
			return  0 ;
		}else {
        System.out.println("function call "+n/10);
			return 1 + numberOfdigits(n/10) ;
		}
	}
  static int reverseRecur(int n,int temp) {
		if(n == 0) {
 
			return temp ;
		}else {
      temp=(temp*10 + n%10);
       //System.out.println("recursive number"+ (10)*(n%10));
			return reverseRecur(n/10,temp) ;
		}
	}
    public static void main(String[] args){
        System.out.print("Enter a number: ");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        if(isPalindrome(n))
            System.out.println(n+" is a palindrome");
        else
            System.out.println(n+" is not a palindrome");
      //int t=reverseRecur(121,1);
  System.out.println("reverse is "+reverseRecur(121,0));
    }

}