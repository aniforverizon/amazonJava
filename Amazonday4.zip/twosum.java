import java.util.*;
 
class SumTwo1{
 
    public int[] findTwo(int []nums,int target){
        int k=0;
        int[] a=new int[6];
        for (int i=0;i<nums.length;i++){
            for (int j=i+1;j<nums.length;j++){
                if (nums[i]+nums[j]==target){
                    a[k]=nums[i];
                    a[k+1]=nums[j];
                    k+=2;
                }
            }
        }
        return a;
    }
    public int [] sumTwo(int [] nums, int target){
 
        Map<Integer,Integer> foundSet=new HashMap<>();
 
        int [] returns =new int [2];
 
        for (int i=0;i<nums.length;i++){
            Integer now=nums[i];
            //13 to be the sum =>2 , 11
            Integer lookingFor=target-now;
            if (foundSet.containsKey(lookingFor)){
                returns[0]=foundSet.get(lookingFor);
                returns[1]=i;
                return returns;
            }else{
                foundSet.put(now,i);
            }
 
        }
 
        return returns;
    }
    public static void main(String args[]){
 
        SumTwo st1=new SumTwo();
 
        int[] arr=new int[2];
        //arr=st1.sumTwo(new int[]{2,7,11,15,1,12},13);
        //System.out.println(arr[0]+ " " + arr[1]  );
        //System.out.println(arr.length);
   /* for (int element:arr){
      System.out.println(element);
    }*/
//        int[] rr=new int[2];
//        rr=st1.findTwo(new int[]{2,7,11,15,1,12},13);
//        for (int element:rr){
//            System.out.println(element);
//        }
        int[] x=new int[6];
        x=st1.findTwo(new int[]{2,5,11,15,1,12},16);
      int m[]={2,5,11,15,1,12};
        for(int i=0;i<x.length;i++){
            System.out.println(m[x[i]]+" "+m[x[i+1]]);
            
        }
    }
}
