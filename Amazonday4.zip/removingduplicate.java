//[1,1,2,2,3,4,4,] //sorted array
//[1,2,3,4] => along with length =>4
//array operations , lets not use set

//we can fill a new array, we dont have to

class RemDup{

  public static int removeDups(int [] nums){
    int i=nums.length>0 ? 1: 0;
    int total=0;
    for (int n :nums){
      if(n>nums[i-1])
        nums[i++]=n;
      ++total;
    }
     
    
    return i;
    }
  
  public static void main(String args[]){

    int a[]={1,1,2,2,3,3,4,4,5};
    System.out.println("unique elements "+removeDups(a));

    
  }
    
  }