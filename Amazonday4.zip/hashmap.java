import java.util.*;

class HashMap1{


  public static void main(String args[]){
    Map map=new HashMap();

    map.put("area","Tanay");
    map.put(5,"Yash");
    map.put(2,"Gourab");

    Set set=map.entrySet();
    Iterator itr=set.iterator();

    while (itr.hasNext()){

      Map.Entry entry=(Map.Entry)itr.next();
      System.out.println(entry.getKey()+ " " +entry.getValue());
    }
  }
}