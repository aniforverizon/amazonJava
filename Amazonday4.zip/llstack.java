class Node {
  int data;
//JVM automatically will create one if you have not declared
  Node next; //self referential => point to another node which is of same type
}

//push, pop, peek=> to get the top element of stack
class Stack{
// private is an access modifier
  //data members
  //should not be accessed by objects directly
  private Node top;
  private int nodeCount;

  //data members are declared private, because they can be accessed via member functions (which are public) , also constructor can access the private data members
  public Stack(){ //for initialization of data members
  this.top=null; //as soon as object gets created , initialization takes place
    this.nodeCount=0;  //this =>means refer to this class
    
  }
//member methods
  public void push(int x){
    Node node1=new Node(); // heap comes into picture

      //new => means heap => these object will be dynamic memory allocation and hence stored on heap
    if (node1==null){
      System.out.println("Heap is overflow");
      return;
    }
    //my git commited codes for learning 
      System.out.println("Lets start inserting ");
    //setting value of the node
     node1.data=x;
    //LIFO => we will make it the new top
    node1.next=top;
    //update the top pointer
    top=node1;
    this.nodeCount+=1;
    
  }

  public boolean isEmpty(){
    return top== null;
  }

  //returning the top value
  //getting value of the top 
  //getters and setters
  public int peek(){
    if (isEmpty()){
      System.out.println("the stack is empty");
      System.exit(-1);
    }
    return top.data;
  }
  public int pop(){
    if (isEmpty()){
      System.out.println("Stack Underflow");
      System.exit(-1);
    }
    int top=peek();

    System.out.println("removing the element "+ top);
    this.nodeCount-=1;
    this.top=(this.top).next;
    return top;
  }

  public int size(){
    return this.nodeCount;
  }

  public void print(){
  Node n1=new Node();
    n1=top;
    for (int i=0;i<nodeCount;i++){
      System.out.println("node is "+n1);
      System.out.println("value is "+n1.data);
      n1=n1.next;
    }
    
  }
}
class Main{

  public static void main(String args[]){
    // cannot instantiate an object if constructor in class is private, only and only if it is public, instantiation will take place
    Stack st1=new Stack();
    st1.push(1);
    st1.push(2);
    st1.push(3);
    System.out.println("top element is "+ st1.peek());

    st1.pop();
    st1.print();
    
  }
}