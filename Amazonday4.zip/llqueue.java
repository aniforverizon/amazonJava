class LLNode{
		int data;
		LLNode next=null;
		LLNode(int x){
			this.data = x;
		}
	}
 
class QueueL{
	LLNode head = null;
	LLNode tail = null;
	int cap;
	int nodeC=0;
 
	QueueL(int cap) {
		this.cap= cap;
	}
 
	void enqueue(int x) {
		if(nodeC == cap) {
			System.out.println("Queue full");
		}else {
			if(tail == null) {
				//first node
				tail = new LLNode(x);
				head = tail;
			}else {
				tail.next = new LLNode(x);
				tail = tail.next;
			}
			nodeC++;
		}
	}
 
	void dequeue() {
		if(head == null) {
			System.out.println("Queue empty");
		}else {
			if(head == tail) {
				//only 1 node
				head = null;
				tail = null;
			}else {
				//more that 1 node
				head = head.next;				
			}
			nodeC--;
		}
	}
 
	void display() {
		if(!isEmpty()) {
			LLNode trav = head;
			while(trav != null) {
				//if(trav == tail) {
			//	System.out.println("Last added Node: "+trav.data);
				//}
        //else {
					System.out.println("Node: "+trav.data);
				//}
				trav=trav.next;
			}
		}else {
			System.out.println("Empty Q!");
		}
 
	}
 
	boolean isEmpty() {
		return tail == null;
	}
 
}

class QueueLL {
 
	public static void main(String[] args) {
		QueueL test = new QueueL(5);
		test.enqueue(34);
		test.enqueue(45);
		test.enqueue(55);
		test.display();
		test.dequeue();
		test.dequeue();
    
    test.display();
		test.dequeue();

    test.dequeue();
test.display();
		
    
    //test.dequeue();
		//test.display();
 
 
	}
 
}
 
