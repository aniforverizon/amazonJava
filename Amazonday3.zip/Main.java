class Main {
  public static int find(int [] arr, int value){
    int i, count=0;
    //1,2,1,1,5,5,6,7,8,1,1
    for (i=0;i<arr.length;i++){
      //whenever there will be occurance , for comparison we will use the == operator , = is for assignment, == comparison
      if (arr[i]==value){ //1==1, 1==2,1==1,1==1,1==5,1==5
                System.out.println(arr[i]+" == " + value);
        //count=count+1;
        return 0;
      }
      else{
        System.out.println(arr[i]+" ! =" + value);
      }
    }
    return count;
  }
  public static void main(String[] args) {
    System.out.println("Hello world!");
    int arr[]={3,4,5,6,7,8,9};
    
    System.out.println("the number of occurances for 1 is "+find(arr,9));
    
}
  }


///1,2,1,1,5,5,6,7,8,1,1

//how many times each and every array element is occuring ?
// 1=> 5 times
//2=> 1 time
//5=> 2 times

//6 => 1 time
