//cchiccxxhixxhixxhillhioohipphihiuu
class CountHi{

  public static int hiCounter(String str){
    int length=str.length();
    if(length==0 || length ==1){
      return 0;
    }
    else {
      System.out.println("argument is "+str.substring(0,2));
      if (str.substring(0,2).equals("hi")){
        return 1+ hiCounter(str.substring(2));
        
      }else{
        return hiCounter(str.substring(1));
      }
    }
  }
  
public static void main(String args[]){
System.out.println("the count of hi iis cchiccxxhixxhixxhillhioohipphihiuu " + hiCounter("cchiccxxhixxhixxhillhioohipphihiuu"));
System.out.println("the count of hi iis ccchrighihhi " + hiCounter("ccchrighihhi"))  ;
}
  
}