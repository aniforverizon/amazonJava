//123 => 1+2+3=> 6
class SumDigits{

  public static int sumDigits(int n){
    if (n<10){ // we will the sum number itself, where recursion is going to stop
      System.out.println("final return"+n);
      return n;
    }
    else { // sum by extracting the last digit
      
      System.out.println(n%10+"sumdigits(n/10)"+n/10);
      return (n%10)+ sumDigits(n/10); //4 +sumDigits(123)
      //3+sumDigits(12)
      //2+sumDigits(1)
      //1+sumDigits(0)
    }
  }

  public static void main(String args[]){

    System.out.println("Sum of digits 1234 is "+ sumDigits(1234));
  }
}