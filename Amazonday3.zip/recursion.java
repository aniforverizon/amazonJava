class factorial{

public static void iteration(){
      int num=6;
    int fact=1;
    for (int i=num;i>=1;i--){
    fact=fact*i;
      
    }
    System.out.println("factorial of number is "+fact );
    }

  public static long multiplyNumbers (long num){
      if (num>=1)
        return num*multiplyNumbers(num-1);
    else //0!= 1
        return 1;
    //multiplyNumbers(6) =6* multiplyNumbers(5)  //6 *5 !
    //multiplyNumbers(5)= 5* multiplyNumbers(4) //5*4*3*2*1
    //multiplyNumbers(4)= 4* multiplyNumbers(3) //4*3*2*1
    //multiplyNumbers(3)= 3* multiplyNumbers(2) /3*2*1
    //multiplyNumbers(2)= 2* multiplyNumbers(1) //2*1
    //multiplyNumbers(1)= 1* multiplyNumbers(0)//1*0
    // multiplyNumbers(0) =1
    
    }
  public static void main(String args[]){
//loops or you can use recusrsion
    

        System.out.println("factorial of number is "+multiplyNumbers (100) );
    
  }
}