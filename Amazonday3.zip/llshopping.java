import java.util.*;
 
class Linkedl2 {
	static class Node{
		String product;
		int cost;
		int id;
		Node next = null;
		Node(String a, int b){
			this.product= a;
			this.cost = b;
 
		}
	}
	static void show(Node head) {
		head = head.next;
		while(head!=null) {
			System.out.println(head.id+". "+head.product);
		}
	}
 
	static int total(Node head) {
		int total = 0;
		head = head.next;
		while(head!=null) {
			total+=head.cost;
			head=head.next;
		}
		return total;
	}
//	static removeItem(Node head, int id) {
//		
//	}
 
	public static void main(String[] args) {
		Node head = new Node("start", 1);
		Node trav = head;
		Scanner sc = new Scanner(System.in);
 
		System.out.println("Do you want to add products?(1/0)");
 
		while(sc.nextInt() == 1) {
//			System.out.println("Product id: ");
//			int id = sc.nextInt();
 
			System.out.println("Product Name: ");
			String prod = sc.nextLine();
			sc.nextLine();
			System.out.println("Product Cost: ");
			int cost = sc.nextInt();
 
			trav.next = new Node(prod, cost);
			trav = trav.next;
			System.out.println("Do you want to add products?(1/0)");
		}
 
 
		System.out.println("Total cost is : "+ total(head));
 
 
	}
}
 
