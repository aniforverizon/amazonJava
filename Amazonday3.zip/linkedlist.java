class LinkedList{

  public static class Node{

    int data;
    String Name;
    String hobby;
    Node next;
  }
  public static void main(String args[]){

    Node newnode1=new Node();
      Node newnode2=new Node();
      Node newnode3=new Node();
      Node newnode4=new Node();
    newnode1.data=1;
    newnode1.Name="anubhav";
    
    newnode2.data=2;
    newnode2.Name="priyanka";
    newnode3.data=3;
    newnode3.Name="nagendra";
    newnode4.data=4;
    newnode4.Name="tanay";
    newnode1.next=newnode2;
    newnode2.next=newnode3;
    newnode3.next=newnode4;
    newnode4.next=null;

    for (int i=0;i<4;i++){
      System.out.println("node data " + i + " is " + newnode1.data);
   System.out.println("node data " + i + " is " + newnode1.Name);
   
      newnode1=newnode1.next;
    }

    
    
  }
  
}