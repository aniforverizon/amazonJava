//1,2,3,4,5
//1,8,27,64,125

 class arr2 {
    public static void main(String[] args)
    {
        //cube of elements in array
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int[] arr1 = cube(arr);
 
        System.out.println("Cube of all the elements of array are:");
        for(int i = 0; i < arr.length; i++)
        {            
            System.out.print(arr1[i] + ", ");
        }
    }
 
    public static int[] cube(int[] arr)
    {
        int[] arr1 = new int[arr.length];
        for (int i = 0; i < arr.length; i++)
        {
            arr1[i] = arr[i] * arr[i] * arr[i];
        }
        return arr1;
    }
}