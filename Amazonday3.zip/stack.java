import java.util.*;

class Stack{

  int arr[],top,capacity;
  //initialize the data members of the class
  
  public Stack(int size){
    arr=new int[size];
    top=-1;
    capacity=size;
  }

  void push(int data){
    if (top>=capacity-1)
    {
      System.out.println("stack is full");
    }
    else{
      ++top;
      arr[top]=data;
      System.out.println(arr[top] + " item is pushed");
    }
  }
    void pop(){
    if (top<=0)
    {
      System.out.println("No more values in Stack");
    }
    else{
      --top;
      System.out.println("item is popped");
    }
  }

  void print(){
 System.out.println("printing values");
    for (int i=0;i<=top;i++){
       System.out.println(arr[i]);
      
    }
  }

  public static void main(String args[]){
    Stack st1=new Stack(5);
    st1.push (1);
    st1.push (4);
    st1.push (9);
    st1.push (16);
        st1.push (25);
    st1.print();
    st1.pop();
    st1.pop();
    st1.print();
    
    
  }
}